"""Evaluator-side generation: balanced history -> public records -> causal mutations."""
import copy
import csv
import hashlib
import hmac
import json
import random
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from schemas import VERSION, TYPES

def convert(amount, rate, source_exp=2, target_exp=2):
    return int((Decimal(amount)*Decimal(rate)*Decimal(10)**(target_exp-source_exp)).quantize(Decimal(1),rounding=ROUND_HALF_UP))

def generate(seed, config=None, secret=b'OPEN-DEVELOPMENT-ONLY'):
    config=dict(config or {})
    unknown=set(config)-{'clean','types','interactions','n_invoices','timezone_offset','permutation','base_currency'}
    if unknown:
        raise ValueError('unknown generator option')
    n=config.get('n_invoices',50)
    if type(n) is not int or not 50 <= n <= 100:
        raise ValueError('n_invoices must be 50..100')
    enabled=config.get('types',list(TYPES))
    if not isinstance(enabled,list) or any(x not in TYPES for x in enabled):
        raise ValueError('invalid types')
    if config.get('clean',False): enabled=[]
    offset=config.get('timezone_offset',5)
    if type(offset) is not int or not -12<=offset<=14: raise ValueError('invalid timezone')
    tz=timezone(timedelta(hours=offset)); base=config.get('base_currency','USD')
    if base not in ('USD','KZT'): raise ValueError('base currency must be USD or KZT')
    # Closed records must not fingerprint a small public seed dictionary either.
    semantic={k:v for k,v in config.items() if k!='permutation'}
    private_seed=hmac.new(secret,json.dumps(['rng',VERSION,seed,semantic],sort_keys=True).encode(),hashlib.sha256).digest()
    rng=random.Random(int.from_bytes(private_seed,'big')); used=set()
    def uid():
        while True:
            value='r'+format(rng.getrandbits(80),'020x')
            if value not in used:
                used.add(value); return value
    period_start=datetime(2026,1,1,tzinfo=tz); period_end=datetime(2026,2,1,tzinfo=tz)
    tables={x:[] for x in ('ledger','invoices','payments','fx')}
    fx={}
    for i in range(35):
        date=(period_start+timedelta(days=i)).date().isoformat()
        rate=str(Decimal('1.05')+Decimal(i)*Decimal('0.003')+Decimal(rng.randrange(10))/10000)
        if base=='KZT': rate=str(Decimal(rate)*500)
        row=dict(rate_id=uid(),date=date,source_currency='EUR',target_currency=base,rate=rate)
        fx[date]=row; tables['fx'].append(row)
    policy=dict(policy_id='policy-v2',fx_date='payment_timestamp_local_date',period_interval='[start,end)',
                rounding='ROUND_HALF_UP',amount_tolerance_minor=0,base_currency=base,
                period_start=period_start.isoformat(),period_end=period_end.isoformat(),
                allocation_rule='invoice_refs must allocate the signed payment amount to remittance_invoice_ids',
                cutoff_rule='invoice posting timestamp must equal issued_at; invoice issue date controls recognition',
                duplicate_rule='same entity_id and supplier_number identifies one economic invoice',
                csv_null_literal='null',
                currency_exponents={base:2,'EUR':2})
    def posting(timestamp,amount,entity,invoice,payment,kind,debit,credit):
        pair=[]
        for account,d,c in [(debit,amount,0),(credit,0,amount)]:
            if amount<0: d,c=-c,-d
            row=dict(row_id=uid(),timestamp=timestamp,account=account,debit_minor=d,credit_minor=c,
                     currency=base,entity_id=entity,invoice_id=invoice,payment_id=payment,posting_kind=kind)
            tables['ledger'].append(row); pair.append(row)
        return pair
    invoice_postings={}; payment_postings={}; payments=[]
    for i in range(n):
        entity='Synthetic Vendor '+str(rng.randrange(1000,9999))
        day=period_start+timedelta(days=rng.randrange(0,25),hours=rng.randrange(24))
        if i==3: day=period_end+timedelta(hours=1)
        currency='EUR' if i in (2,4,6) or rng.random()<.25 else base
        amount=100000 if i%9==0 else rng.randrange(10000,500000)
        inv=dict(doc_id=uid(),invoice_id=uid(),entity_id=entity,supplier_number='S'+str(rng.getrandbits(40)),
                 issued_at=day.isoformat(),due_at=(day+timedelta(days=30)).isoformat(),currency=currency,
                 total_minor=amount,line_items=[dict(description='Synthetic service',amount_minor=amount)])
        tables['invoices'].append(inv)
        rate=fx[day.date().isoformat()]['rate'] if currency!=base else '1'
        invoice_postings[inv['invoice_id']]=posting(day.isoformat(),convert(amount,rate),entity,inv['invoice_id'],None,'invoice','expense','payable')
        pd=day+timedelta(days=1); rate=fx[pd.date().isoformat()]['rate'] if currency!=base else '1'
        # Clean split payments and refunds are genuine accounting events, not errors.
        parts=[amount]
        if i==8: parts=[amount//2,amount-amount//2]
        if i==9: parts=[amount+1000,-1000]
        for part in parts:
            pay=dict(doc_id=uid(),payment_id=uid(),timestamp=pd.isoformat(),currency=currency,
                     amount_minor=part,invoice_refs=[dict(invoice_id=inv['invoice_id'],amount_minor=part)],
                     remittance_invoice_ids=[inv['invoice_id']],fx_date=pd.date().isoformat(),
                     fx_rate=rate,base_amount_minor=convert(part,rate))
            tables['payments'].append(pay); payments.append((i,pay,inv))
            payment_postings[pay['payment_id']]=posting(pd.isoformat(),pay['base_amount_minor'],entity,inv['invoice_id'],pay['payment_id'],'payment','payable','cash')
        paid_base=sum(p['base_amount_minor'] for idx,p,_ in payments if idx==i)
        invoice_base=invoice_postings[inv['invoice_id']][0]['debit_minor']
        difference=paid_base-invoice_base
        if difference:
            posting(pd.isoformat(),difference,entity,inv['invoice_id'],None,'fx_adjustment','fx_loss','payable')
    history=copy.deepcopy(tables)
    truth=[]; changes=[]
    def issue(kind,ids,amount,currency,evidence,before,after):
        iid='issue-'+str(len(truth)+1)
        truth.append(dict(issue_id=iid,type=kind,affected_ids=sorted(ids),expected_amount_minor=amount,
                          currency=currency,evidence_sets=[sorted(evidence)]))
        changes.append(dict(issue_id=iid,type=kind,before=before,after=after))
    def allocation(index):
        _,pay,inv=next(x for x in payments if x[0]==index)
        before=copy.deepcopy(pay); lost=pay['amount_minor']//3
        pay['invoice_refs'][0]['amount_minor']-=lost
        issue('missing_or_partial_payment_allocation',[pay['payment_id'],inv['invoice_id']],lost,pay['currency'],
              [pay['doc_id'],inv['doc_id'],'policy-v2'],before,copy.deepcopy(pay))
    def badfx(index,kind):
        _,pay,inv=next(x for x in payments if x[0]==index)
        before=copy.deepcopy(pay); rows=payment_postings[pay['payment_id']]; before_rows=copy.deepcopy(rows)
        correct=pay['base_amount_minor']; date=pay['fx_date']
        if kind=='wrong_fx_date':
            pay['fx_date']=(datetime.fromisoformat(pay['timestamp'])+timedelta(days=1)).date().isoformat()
            pay['fx_rate']=fx[pay['fx_date']]['rate']
        else: pay['fx_rate']=str(Decimal(pay['fx_rate'])+Decimal('0.03'))
        pay['base_amount_minor']=convert(pay['amount_minor'],pay['fx_rate'])
        for row in rows:
            if row['debit_minor']: row['debit_minor']=pay['base_amount_minor']
            if row['credit_minor']: row['credit_minor']=pay['base_amount_minor']
        issue(kind,[pay['payment_id']],abs(pay['base_amount_minor']-correct),base,
              [pay['doc_id'],fx[date]['rate_id'],'policy-v2'],
              dict(payment=before,ledger=before_rows),dict(payment=copy.deepcopy(pay),ledger=copy.deepcopy(rows)))
    def duplicate(index):
        inv=tables['invoices'][index]; dup=copy.deepcopy(inv); dup['invoice_id']=uid(); dup['doc_id']=uid()
        tables['invoices'].append(dup)
        original=invoice_postings[inv['invoice_id']]
        rows=posting(inv['issued_at'],original[0]['debit_minor'],inv['entity_id'],dup['invoice_id'],None,'invoice','expense','payable')
        issue('duplicate_invoice',[inv['invoice_id'],dup['invoice_id']],inv['total_minor'],inv['currency'],
              [inv['doc_id'],dup['doc_id'],'policy-v2'],None,dict(invoice=copy.deepcopy(dup),ledger=copy.deepcopy(rows)))
    if 'duplicate_invoice' in enabled: duplicate(0)
    if 'missing_or_partial_payment_allocation' in enabled: allocation(1)
    if 'wrong_fx_rate' in enabled: badfx(2,'wrong_fx_rate')
    if 'wrong_fx_date' in enabled: badfx(4,'wrong_fx_date')
    if 'period_cutoff_error' in enabled:
        inv=tables['invoices'][3]; rows=invoice_postings[inv['invoice_id']]; before=copy.deepcopy(rows)
        for row in rows: row['timestamp']=(period_end-timedelta(hours=1)).isoformat()
        issue('period_cutoff_error',[inv['invoice_id']]+[r['row_id'] for r in rows],rows[0]['debit_minor'],base,
              [inv['doc_id']]+[r['row_id'] for r in rows]+['policy-v2'],before,copy.deepcopy(rows))
    if config.get('interactions',True):
        if 'missing_or_partial_payment_allocation' in enabled and 'wrong_fx_rate' in enabled:
            allocation(6); badfx(6,'wrong_fx_rate')
        if 'duplicate_invoice' in enabled and 'missing_or_partial_payment_allocation' in enabled:
            duplicate(7); allocation(7)
    semantic={k:v for k,v in config.items() if k!='permutation'}
    message=json.dumps([VERSION,seed,semantic],sort_keys=True).encode()
    episode_id='ep-'+hmac.new(secret,message,hashlib.sha256).hexdigest()[:24]
    public=dict(manifest=dict(schema_version=VERSION,episode_id=episode_id,base_currency=base,
                period_start=period_start.isoformat(),period_end=period_end.isoformat(),timezone=period_start.strftime('%z'),
                currency_exponents={base:2,'EUR':2},counts={k:len(v) for k,v in tables.items()},rounding='ROUND_HALF_UP'),
                policy=policy,tables=tables)
    public['manifest']['record_count']=sum(len(rows) for rows in tables.values())
    public['manifest']['document_count']=len(tables['invoices'])+len(tables['payments'])
    package=dict(public=public,truth=truth,provenance=dict(schema_version=VERSION,seed=seed,config=config,history=history,changes=changes))
    if config.get('permutation') is not None:
        transform(package,config['permutation'])
    return package

def record_id(table,row):
    return row[{'ledger':'row_id','invoices':'invoice_id','payments':'payment_id','fx':'rate_id'}[table]]

def transform(package,seed):
    rng=random.Random(str(seed)); ids=set()
    for table,rows in package['public']['tables'].items():
        for row in rows:
            ids.add(record_id(table,row))
            if 'doc_id' in row: ids.add(row['doc_id'])
    mapping={old:'m'+format(rng.getrandbits(100),'025x') for old in sorted(ids)}
    def walk(x):
        if isinstance(x,str): return mapping.get(x,x)
        if isinstance(x,list): return [walk(v) for v in x]
        if isinstance(x,dict): return {k:walk(v) for k,v in x.items()}
        return x
    for key in ('public','truth','provenance'): package[key]=walk(package[key])
    for rows in package['public']['tables'].values(): rng.shuffle(rows)
    return mapping

def export(package,public_dir,private_dir):
    public_dir=Path(public_dir); private_dir=Path(private_dir)
    public_dir.mkdir(parents=True,exist_ok=True); private_dir.mkdir(parents=True,exist_ok=True)
    for name in ('manifest','policy'):
        (public_dir/(name+'.json')).write_text(json.dumps(package['public'][name],ensure_ascii=False,indent=2),encoding='utf-8')
    for table,rows in package['public']['tables'].items():
        if table in ('ledger','fx'):
            with (public_dir/(table+'.csv')).open('w',newline='',encoding='utf-8') as f:
                writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader()
                writer.writerows({k:('null' if v is None else v) for k,v in row.items()} for row in rows)
        else:
            (public_dir/(table+'.jsonl')).write_text(''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in rows),encoding='utf-8')
    for name in ('truth','provenance'):
        (private_dir/(name+'.json')).write_text(json.dumps(package[name],ensure_ascii=False,indent=2),encoding='utf-8')

def load_public(directory):
    directory=Path(directory)
    public={name:json.loads((directory/(name+'.json')).read_text(encoding='utf-8')) for name in ('manifest','policy')}
    tables={}
    for table in ('ledger','fx'):
        with (directory/(table+'.csv')).open(newline='',encoding='utf-8') as stream: rows=list(csv.DictReader(stream))
        for row in rows:
            for key,value in row.items():
                if key.endswith('_minor'): row[key]=int(value)
                elif key in ('invoice_id','payment_id') and value=='null': row[key]=None
        tables[table]=rows
    for table in ('invoices','payments'):
        tables[table]=[json.loads(line) for line in (directory/(table+'.jsonl')).read_text(encoding='utf-8').splitlines() if line]
    public['tables']=tables
    return public
