"""Versioned public protocol. All money is signed integer minor units."""
VERSION = '2.0.0'
TYPES = ('duplicate_invoice', 'missing_or_partial_payment_allocation',
         'wrong_fx_rate', 'wrong_fx_date', 'period_cutoff_error')
TABLES = ('ledger', 'invoices', 'payments', 'fx')
MAX_STEPS = 100

def finding(kind, ids, amount, currency, evidence, explanation='Public records establish the discrepancy.'):
    return dict(type=kind, affected_ids=sorted(set(ids)), claimed_amount_minor=amount,
                currency=currency, evidence_ids=sorted(set(evidence)), explanation=explanation)

def validate(payload, episode_id):
    if not isinstance(payload, dict) or set(payload) != {'episode_id', 'findings'}:
        raise ValueError('invalid submission envelope')
    if payload['episode_id'] != episode_id:
        raise ValueError('episode mismatch')
    items = payload['findings']
    if not isinstance(items, list) or len(items) > 30:
        raise ValueError('invalid findings count')
    keys = {'type','affected_ids','claimed_amount_minor','currency','evidence_ids','explanation'}
    for f in items:
        if not isinstance(f, dict) or set(f) != keys or f['type'] not in TYPES:
            raise ValueError('invalid finding')
        for key, minimum, maximum in [('affected_ids',1,30),('evidence_ids',0,10)]:
            seq = f[key]
            if not isinstance(seq,list) or not minimum <= len(seq) <= maximum:
                raise ValueError('invalid ID count')
            if any(not isinstance(x,str) or not 1 <= len(x) <= 128 for x in seq):
                raise ValueError('invalid ID')
            if len(set(seq)) != len(seq):
                raise ValueError('duplicate ID in finding')
        if type(f['claimed_amount_minor']) is not int or abs(f['claimed_amount_minor']) > 10**18:
            raise ValueError('invalid amount')
        if not isinstance(f['currency'],str) or len(f['currency']) != 3 or not f['currency'].isascii() or not f['currency'].isupper() or not f['currency'].isalpha():
            raise ValueError('invalid currency')
        if not isinstance(f['explanation'],str) or len(f['explanation']) > 1000:
            raise ValueError('invalid explanation')
    return items
