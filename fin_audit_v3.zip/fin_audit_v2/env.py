"""Trusted evaluator service. Never give this object or its process to an untrusted policy."""
import ast
import copy
import json
import time
from decimal import Decimal, localcontext
from data import generate, record_id
from matcher import score
from schemas import MAX_STEPS, TABLES

def calculate(expression):
    if not isinstance(expression,str) or not 1<=len(expression)<=200:
        raise ValueError('invalid expression length')
    tree=ast.parse(expression.strip(),mode='eval')
    nodes=list(ast.walk(tree))
    if len(nodes)>100: raise ValueError('expression too complex')
    def run(node,depth=0):
        if depth>25: raise ValueError('expression too deep')
        if isinstance(node,ast.Constant) and type(node.value) in (int,float):
            text=ast.get_source_segment(expression.strip(),node)
            if any(c not in '0123456789.' for c in text): raise ValueError('decimal literals only')
            return Decimal(text)
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
            v=run(node.operand,depth+1); return v if isinstance(node.op,ast.UAdd) else -v
        if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult,ast.Div)):
            a=run(node.left,depth+1); b=run(node.right,depth+1)
            if isinstance(node.op,ast.Add): return a+b
            if isinstance(node.op,ast.Sub): return a-b
            if isinstance(node.op,ast.Mult): return a*b
            return a/b
        raise ValueError('unsupported arithmetic')
    with localcontext() as ctx:
        ctx.prec=40; ctx.Emax=200; ctx.Emin=-200
        value=run(tree.body)
    if not value.is_finite() or abs(value.adjusted())>200: raise ValueError('result too large')
    return format(value,'f')

class FinanceAuditEnv:
    def __init__(self,mode='eval',secret=None,clock=time.monotonic,time_limit=60):
        if mode not in ('train','dev','eval'): raise ValueError('unknown mode')
        if mode=='eval' and (not isinstance(secret,bytes) or len(secret)<32):
            raise ValueError('closed evaluation requires a private >=32 byte key')
        self.mode=mode; self.secret=secret or b'OPEN-DEVELOPMENT-ONLY'; self.clock=clock; self.time_limit=time_limit
        self.package=None; self.done=False; self.steps=0; self.inspections=0; self.result=None; self.trajectory=[]

    def reset(self,seed=0,config=None):
        self.package=generate(seed,config,self.secret); self.public=self.package['public']
        self.steps=0; self.inspections=0; self.done=False; self.terminated=False; self.truncated=False
        self.result=None; self.trajectory=[]; self.start=self.clock()
        self.index={t:{record_id(t,r):r for r in rows} for t,rows in self.public['tables'].items()}
        self.docs={r['doc_id']:r for t in ('invoices','payments') for r in self.public['tables'][t]}
        self.valid_ids=set(self.docs)|{'policy-v2'}|{i for table in self.index.values() for i in table}
        return copy.deepcopy(dict(episode_id=self.public['manifest']['episode_id'],task='Audit the synthetic company and submit evidence-backed findings.',
                    manifest=self.public['manifest'],policy=self.public['policy'],steps_remaining=100)),{}

    def obs(self,**extra): return dict(steps_remaining=max(0,100-self.steps),**extra)

    def truncate(self,reason):
        self.done=True; self.truncated=True
        self.result=dict(valid=False,status='truncated',reason=reason,reward=0.0,final_answer=None)
        return self.obs(ok=False,error='episode truncated',final_answer=None),0.0,False,True,{}

    def step(self,action):
        if self.package is None: raise RuntimeError('reset required')
        if self.done: return self.obs(ok=False,error='episode finished'),0.0,self.terminated,self.truncated,{}
        if self.clock()-self.start>=self.time_limit: return self.truncate('timeout')
        self.steps+=1
        try:
            serialized=json.dumps(action,allow_nan=False)
            if len(serialized)>65536: raise ValueError('action too large')
            logged_action=json.loads(serialized)
        except (TypeError,ValueError,RecursionError):
            action=None; logged_action=None
        try:
            if not isinstance(action,dict) or set(action)-{'tool','args'}: raise ValueError('invalid action')
            tool=action.get('tool'); args=action.get('args',{})
            if not isinstance(tool,str) or tool not in ('list_records','get_record','get_document','calculator','submit') or not isinstance(args,dict):
                raise ValueError('invalid action')
            if len(json.dumps(action,allow_nan=False))>65536: raise ValueError('action too large')
            if tool=='submit':
                self.done=True; self.terminated=True
                payload=args.get('findings') if set(args)=={'findings'} else None
                self.result=score(payload,self.public['manifest']['episode_id'],self.package['truth'],self.valid_ids,self.inspections)
                self.result['final_answer']=copy.deepcopy(payload) if self.result['valid'] else None
                reward=self.result['reward'] if self.mode!='eval' else 0.0
                out=(self.obs(ok=True,result='submitted'),reward,True,False,{})
            else:
                self.inspections+=1
                result=self.tool(tool,args)
                out=(self.obs(ok=True,result=result),0.0,False,False,{})
        except (ValueError,TypeError,KeyError,ArithmeticError,SyntaxError,RecursionError):
            if self.inspections<self.steps: self.inspections+=1
            out=(self.obs(ok=False,error='invalid request'),0.0,False,False,{})
        if self.clock()-self.start>=self.time_limit:
            self.terminated=False; out=self.truncate('timeout')
        elif not self.done and self.steps>=MAX_STEPS: out=self.truncate('step limit')
        self.trajectory.append(dict(episode_id=self.public['manifest']['episode_id'],step=self.steps,action=logged_action,
                                   observation=copy.deepcopy(out[0]),reward=out[1],terminated=out[2],truncated=out[3]))
        return out

    def tool(self,tool,args):
        if tool=='calculator':
            if set(args)!={'expression'}: raise ValueError()
            return {'value':calculate(args['expression'])}
        if tool=='get_document':
            if set(args)!={'doc_id'} or not isinstance(args['doc_id'],str): raise ValueError()
            return copy.deepcopy(self.docs[args['doc_id']])
        table=args.get('table')
        if not isinstance(table,str) or table not in TABLES: raise ValueError()
        if tool=='get_record':
            if set(args)!={'table','id'} or not isinstance(args['id'],str): raise ValueError()
            return copy.deepcopy(self.index[table][args['id']])
        if set(args)-{'table','cursor','limit'}: raise ValueError()
        limit=args.get('limit',50); cursor=args.get('cursor')
        if type(limit) is not int or limit<1: raise ValueError()
        offset=0
        if cursor is not None:
            if not isinstance(cursor,str) or len(cursor)>12 or not cursor.startswith('c') or not cursor[1:].isascii() or not cursor[1:].isdigit(): raise ValueError()
            offset=int(cursor[1:])
        rows=sorted(self.index[table].values(),key=lambda r:record_id(table,r))
        if offset>len(rows): raise ValueError()
        end=offset+min(limit,50)
        return copy.deepcopy(dict(rows=rows[offset:end],next_cursor='c'+str(end) if end<len(rows) else None))
