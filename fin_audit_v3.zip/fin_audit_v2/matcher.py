"""Public deterministic bipartite matching. Exact amounts (tolerance=0 minor units)."""
from schemas import validate

def score(payload, episode_id, truth, valid_ids, inspection_steps):
    try:
        findings = validate(payload, episode_id)
    except (ValueError, TypeError, KeyError):
        return {'valid':False,'reward':-1.0,'error':'invalid submission'}
    ordered = sorted(truth, key=lambda t:t['issue_id'])
    edges = []
    for f in findings:
        evidence = set(f['evidence_ids'])
        candidates = []
        for j,t in enumerate(ordered):
            if (f['type']==t['type'] and sorted(f['affected_ids'])==sorted(t['affected_ids'])
                and f['claimed_amount_minor']==t['expected_amount_minor'] and f['currency']==t['currency']
                and evidence <= valid_ids
                and any(set(required) <= evidence for required in t['evidence_sets'])):
                candidates.append(j)
        edges.append(candidates)
    # Maximum cardinality; stable submission order and issue_id break ties.
    owner = {}
    def augment(i, seen):
        for j in edges[i]:
            if j in seen:
                continue
            seen.add(j)
            if j not in owner or augment(owner[j],seen):
                owner[j]=i
                return True
        return False
    for i in range(len(findings)):
        augment(i,set())
    tp=len(owner); fp=len(findings)-tp; fn=len(truth)-tp
    p=tp/(tp+fp) if tp+fp else 0.0
    r=tp/(tp+fn) if tp+fn else 0.0
    f1=1.0 if not truth and not findings else (2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.0)
    reward=max(-1.0,min(1.0,2*f1-1-0.002*inspection_steps))
    return dict(valid=True,TP=tp,FP=fp,FN=fn,P=p,R=r,F1=f1,reward=reward,
                inspection_steps=inspection_steps,amount_tolerance_minor=0)
