"""Local rehearsal: 20 episodes (5 clean, >=5 interacting) and 20 renamed-ID pairs."""
import argparse
import hashlib
import json
from pathlib import Path
import secrets
import time
from data import generate
from env import FinanceAuditEnv
from runner import oracle,run_episode
from validator import validate_package
from private_config import load_key

def main(backend='process',out=Path('verification')):
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    key=load_key() if backend=='docker' else b'PUBLIC-LOCAL-REHEARSAL-KEY-V2-DO-NOT-USE-CLOSED'
    reports=[]; trajectories=[]; validations=[]; pairs=[]
    for i in range(20):
        config=dict(clean=i<5,interactions=i>=10,n_invoices=50+i%4,timezone_offset=[-5,0,5,9][i%4],base_currency='KZT' if i%3==0 else 'USD')
        validations.append(validate_package(generate(2000+i,config,key)))
        for policy in ('random','reconciliation','flag_all','oracle'):
            env,seconds=run_episode(policy,2000+i,config,backend,key)
            reports.append(dict(episode_id=env.public['manifest']['episode_id'],policy=policy,steps=env.steps,seconds=seconds,
                                terminated=env.terminated,truncated=env.truncated,
                                metrics={k:v for k,v in env.result.items() if k!='final_answer'}))
            trajectories.extend(dict(policy=policy,**t) for t in env.trajectory)
        a=FinanceAuditEnv(secret=key); b=FinanceAuditEnv(secret=key)
        a.reset(2000+i,config); b.reset(2000+i,{**config,'permutation':901+i})
        validate_package(b.package)
        for e in (a,b): e.step(dict(tool='submit',args=dict(findings=oracle(e))))
        same=all(a.result[k]==b.result[k] for k in ('P','R','F1','reward'))
        assert same,'metamorphic oracle failed'
        pairs.append(dict(pair=i,passed=same))
    result=dict(kind='LOCAL_REHEARSAL_NOT_OFFICIAL_SCORE',dataset_mode='closed_local' if backend=='docker' else 'open_reproducible_reference',backend=backend,episode_checks=validations,pair_checks=pairs,runs=reports,
                docker_security_tested=backend=='docker',official_score=None)
    (out/'benchmark.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    (out/'trajectories.jsonl').write_text(''.join(json.dumps(t)+'\n' for t in trajectories),encoding='utf-8')
    print(f'Local rehearsal: {len(validations)} validated episodes, {len(reports)} runs, {len(pairs)} pairs. Backend: {backend}.')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--backend',choices=['docker','process'],default='docker'); p.add_argument('--out',type=Path,default=Path('verification'))
    args=p.parse_args(); main(args.backend,args.out)
