"""Evaluator-owned deployment configuration, never included in the agent image."""
import os
from pathlib import Path
import secrets

def load_key(path=None):
    path=Path(path) if path else Path(__file__).parent/'.evaluator-private'/'key.bin'
    path.parent.mkdir(parents=True,exist_ok=True)
    try:
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    except FileExistsError:
        key=path.read_bytes()
    else:
        key=secrets.token_bytes(32)
        with os.fdopen(fd,'wb') as stream: stream.write(key)
    if len(key)!=32: raise ValueError('private evaluator key must be exactly 32 bytes')
    return key
