"""One verification entry point; portable standard library only."""
import argparse
import io
import json
import platform
from pathlib import Path
import sys
import time
import unittest
from benchmark import main as benchmark

def main():
    p=argparse.ArgumentParser(); p.add_argument('--require-isolation',action='store_true'); p.add_argument('--out',type=Path,default=Path('verification'))
    args=p.parse_args(); args.out.mkdir(parents=True,exist_ok=True); start=time.monotonic()
    stream=io.StringIO(); suite=unittest.defaultTestLoader.discover(str(Path(__file__).parent),pattern='test_*.py')
    test=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    (args.out/'tests.txt').write_text(stream.getvalue(),encoding='utf-8'); print(stream.getvalue())
    report=dict(kind='LOCAL_VERIFICATION_NOT_OFFICIAL_SCORE',python=sys.version,platform=platform.platform(),tests_run=test.testsRun,
                tests_passed=test.wasSuccessful(),official_score=None,security_status='not_run',python311_tested=sys.version_info[:2]==(3,11),
                failures=[],warnings=['Local tests are not the unpublished official checks.'])
    if not test.wasSuccessful(): report['failures'].append('functional tests failed')
    if test.wasSuccessful():
        try:
            if args.require_isolation:
                from security_check import check
                report['security_checks']=check(); report['security_status']='passed_negative_container_checks'
            bench=benchmark('docker' if args.require_isolation else 'process',args.out)
            report['episodes_validated']=len(bench['episode_checks']); report['pairs_validated']=len(bench['pair_checks'])
            report['policy_runs']=len(bench['runs'])
            for run in bench['runs']:
                if run['truncated']: report['failures'].append('policy truncated: '+run['policy'])
                if run['policy'] in ('reconciliation','oracle') and run['metrics'].get('F1')!=1:
                    report['failures'].append('baseline missed a generated discrepancy')
            report['metrics']={}
            for name in ('random','reconciliation','flag_all','oracle'):
                runs=[r for r in bench['runs'] if r['policy']==name]
                report['metrics'][name]={k:sum(r['metrics'].get(k,0) for r in runs)/len(runs) for k in ('P','R','F1','reward')}
                report['metrics'][name]['mean_steps']=sum(r['steps'] for r in runs)/len(runs)
                report['metrics'][name]['mean_seconds']=sum(r['seconds'] for r in runs)/len(runs)
        except (OSError,RuntimeError,AssertionError,TimeoutError) as exc:
            report['failures'].append(type(exc).__name__+': '+str(exc)[:500])
    if not args.require_isolation:
        report['warnings'].append('Isolation NOT verified: process backend is smoke only. Run --require-isolation with Docker.')
    if not report['python311_tested']: report['warnings'].append('Interpreter is not Python 3.11; run supplied 3.11 container.')
    report['seconds']=time.monotonic()-start
    report['functional_status']='passed' if not report['failures'] else 'failed'
    report['submission_readiness']='requires_external_validation' if not report['failures'] else 'blocked'
    (args.out/'summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    return int(bool(report['failures']))

if __name__=='__main__': raise SystemExit(main())
