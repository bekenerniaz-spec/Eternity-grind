param([string]$PythonPath)
$ErrorActionPreference = 'Stop'
$candidates = @()
if ($PythonPath) { $candidates += $PythonPath }
else {
    $systemPython = Get-Command python -ErrorAction SilentlyContinue
    if ($systemPython -and $systemPython.Source -notlike '*\Microsoft\WindowsApps\*') {
        $candidates += $systemPython.Source
    }
    $runtimePackages = @()
    try { $runtimePackages = Get-AppxPackage -Name 'OpenAI.CodexPrimaryRuntime*' -ErrorAction Stop }
    catch { $runtimePackages = @() }
    foreach ($package in $runtimePackages) {
        $candidates += Join-Path $package.InstallLocation 'dependencies\python\python.exe'
    }
    $candidates += 'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1119-907-0_26.1119.907.0_x64__3k8sg7r9htsxt\dependencies\python\python.exe'
}
$selectedPython = $null
foreach ($candidate in $candidates) {
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
    & $candidate -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)' 2>$null
    if ($LASTEXITCODE -eq 0) { $selectedPython = $candidate; break }
}
if (-not $selectedPython) {
    throw 'Python 3.11+ not found. Use -PythonPath with the absolute path to python.exe.'
}
Write-Host "Using: $selectedPython"
Push-Location $PSScriptRoot
try {
    & $selectedPython -B verify.py
    $verificationExitCode = $LASTEXITCODE
} finally { Pop-Location }
exit $verificationExitCode
