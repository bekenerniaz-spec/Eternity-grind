# Карта опубликованных требований

Номера разделов относятся к предоставленному Fintech.pdf. Локальные проверки
не выдаются за официальные фиксированные тесты организаторов.

| Раздел PDF / требование | Реализация | Проверка / результат |
|---|---|---|
| 02: минимум четыре независимо настраиваемых типа | data.generate(types=...), пять подтипов | test_each_type_independently |
| 02: два взаимодействия, чистые случаи, отвлекающие записи | data.py | test_two_interactions, test_clean_split_and_refund |
| 02–03: причинная история, доступные доказательства | provenance, validator, public_validation | causal validator, corrupt truth/history regression |
| 03: manifest, CSV/JSONL, money/time/FX | export, schemas.json, public_validation | test_export_separation, schema/date/integer assertions |
| 03–04: изоляция оценщика | runner Docker backend, separate agent image | security_check.py; требуется Docker-прогон |
| 04: reset/step, только инструменты, пагинация | env.py, agent.Client | Contract tests |
| 04: 100 шагов, submit, timeout | env.step/truncate, bounded runner IPC | test_submit_at_100, test_truncate_at_100, test_timeout |
| 04: отсутствие intermediate reward / eval hints | env mode gating | test_closed_reward_hidden, test_no_labels_in_observation |
| 05: schema/limits, invalid submit | schemas.validate | Matching limits tests, invalid_submit_terminal_hidden |
| 05: one-to-one TP/FP/FN, полные evidence sets | matcher.py | incomplete/guessed evidence, ambiguity, duplicates |
| 05: общая награда и special cases | matcher.score | clean_empty, silence, clean_false_accusation, steps_mild |
| 06: 4 политики на 20 эпизодах | agent.py + trusted oracle, benchmark.py | verification/benchmark.json, 80 запусков |
| 06: 5 clean, 5 interacting, 20 ID/order pairs | benchmark config, data.transform | episode_checks, pair_checks |
| 07: offline, no GPU/API | stdlib code, Docker network=none | функциональный прогон; Docker отрицательные проверки отдельно |
| 09: код/лицензия/README/container | LICENSE, README, Dockerfiles | verify.py; 3.11 container ещё требует запуска |
| 09: 10 train + 10 dev | samples/public, samples/evaluator_only | make_samples.py + validator |
| 09: trajectories/design/demo | verification/trajectories.jsonl, DESIGN | запись каждого agent step без truth/seed |
| 10: измерения, честные ограничения | verify summary, DESIGN | фактические версии, время, failures/warnings |

Шкала: 25 контракт/изоляция + 25 данные/эталон + 25 награда + 15 воспроизводимость
+ 10 инженерия. Официальный балл не вычисляется из локальных тестов.
Изоляцию и профиль Python 3.11 необходимо подтвердить на целевой машине;
подробные скрытые проверки недоступны. Ничего автоматически не отправляется жюри.
