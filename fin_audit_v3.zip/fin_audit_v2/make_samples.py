import argparse
from pathlib import Path
from data import generate,export
from validator import validate_package

def main(root=Path('samples')):
    for split,start in [('train',0),('dev',100)]:
        for i in range(10):
            config=dict(clean=i<2,interactions=i>=5,timezone_offset=[0,5,-5][i%3])
            package=generate(start+i,config)
            validate_package(package)
            export(package,root/'public'/split/f'episode-{i:02}',root/'evaluator_only'/split/f'episode-{i:02}')
    print('Exported 10 train + 10 dev; evaluator_only must never be mounted into the agent.')

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--out',type=Path,default=Path('samples')); main(p.parse_args().out)
