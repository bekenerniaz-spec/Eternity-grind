"""Negative checks inside restricted agent image. Requires local Docker/image."""
import json
import subprocess

PROBE='''
import json,os,socket
r={}
r['nonroot']=os.geteuid()!=0
try:
 open('/agent/unwanted','w').write('x'); r['readonly']=False
except OSError: r['readonly']=True
r['no_evaluator_files']=not any(os.path.exists(p) for p in ['/agent/env.py','/agent/data.py','/agent/runner.py','/agent/truth.json','/var/run/docker.sock','/workspace'])
try:
 s=socket.socket(); s.settimeout(.5); s.connect(('1.1.1.1',443)); r['network_blocked']=False
except OSError: r['network_blocked']=True
finally: s.close()
status=open('/proc/self/status').read()
r['no_new_privileges']='NoNewPrivs:\\t1' in status
r['capabilities_dropped']='CapEff:\\t0000000000000000' in status
r['no_secrets_in_environment']=not any('SECRET' in k or 'SEED' in k or 'TOKEN' in k for k in os.environ)
print(json.dumps(r))
'''

def check():
    command=['docker','run','--rm','--network=none','--read-only','--user','65532:65532',
             '--cap-drop=ALL','--security-opt=no-new-privileges','--pids-limit=32',
             '--cpus=2','--memory=512m','--memory-swap=512m','--tmpfs','/tmp:rw,noexec,nosuid,size=4m',
             '--entrypoint','python','fin-audit-agent:2','-c',PROBE]
    result=subprocess.run(command,capture_output=True,text=True,timeout=30)
    if result.returncode: raise RuntimeError('Docker probe failed: '+result.stderr[-500:])
    checks=json.loads(result.stdout)
    if not all(checks.values()): raise RuntimeError('Isolation checks failed: '+json.dumps(checks))
    return checks

if __name__=='__main__': print(json.dumps(check(),indent=2))
