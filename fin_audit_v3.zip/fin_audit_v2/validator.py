"""Independent checks of public records, clean history, mutation trace, evidence sufficiency."""
import copy
import json
from collections import defaultdict
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from analysis import infer
from data import record_id
from public_validation import validate_public

def canonical(f):
    return (f['type'],tuple(sorted(f['affected_ids'])),f.get('expected_amount_minor',f.get('claimed_amount_minor')),f['currency'])

def validate_package(package):
    if not __debug__: raise RuntimeError('validation requires Python without -O')
    public=package['public']; tables=public['tables']; manifest=public['manifest']; history=package['provenance']['history']
    validate_public(public)
    for name,rows in tables.items():
        assert len(rows)==manifest['counts'][name], 'manifest count mismatch'
        assert len({record_id(name,r) for r in rows})==len(rows), 'duplicate record ID'
        for row in rows:
            for key,value in row.items():
                if key.endswith('_minor'): assert type(value) is int, 'noninteger money'
                if key in ('timestamp','issued_at','due_at'):
                    assert datetime.fromisoformat(value).utcoffset() is not None, 'naive timestamp'
    for source in (history,tables):
        balance=defaultdict(int)
        for row in source['ledger']:
            assert row['debit_minor']>=0 and row['credit_minor']>=0, 'negative ledger side'
            assert not (row['debit_minor'] and row['credit_minor']), 'both ledger sides nonzero'
            balance[(row['invoice_id'],row['payment_id'],row['posting_kind'],row['currency'])]+=row['debit_minor']-row['credit_minor']
        assert all(v==0 for v in balance.values()), 'unbalanced ledger'
    clean=copy.deepcopy(public); clean['tables']=history
    assert infer(clean)==[], 'pre-mutation history is not clean'
    native_paid=defaultdict(int); payable=defaultdict(int)
    by_invoice={r['invoice_id']:r for r in history['invoices']}
    by_payment={r['payment_id']:r for r in history['payments']}
    rates={(r['date'],r['source_currency']):Decimal(r['rate']) for r in history['fx']}
    def value(amount,currency,timestamp):
        rate=Decimal(1) if currency==public['policy']['base_currency'] else rates[(datetime.fromisoformat(timestamp).date().isoformat(),currency)]
        return int((Decimal(amount)*rate).quantize(Decimal(1),rounding=ROUND_HALF_UP))
    for pay in history['payments']:
        for ref in pay['invoice_refs']: native_paid[ref['invoice_id']]+=ref['amount_minor']
        assert pay['base_amount_minor']==value(pay['amount_minor'],pay['currency'],pay['timestamp']),'clean payment valuation mismatch'
    for row in history['ledger']:
        if row['account']=='payable': payable[row['invoice_id']]+=row['credit_minor']-row['debit_minor']
        if row['posting_kind']=='payment' and row['account']=='cash':
            assert row['credit_minor']-row['debit_minor']==by_payment[row['payment_id']]['base_amount_minor'],'cash mismatch'
        if row['posting_kind']=='invoice' and row['account']=='expense':
            inv=by_invoice[row['invoice_id']]
            assert row['debit_minor']==value(inv['total_minor'],inv['currency'],inv['issued_at']),'clean invoice valuation mismatch'
    assert all(native_paid[i]==r['total_minor'] for i,r in by_invoice.items()),'unsettled native invoice'
    assert all(v==0 for v in payable.values()),'unsettled clean payable balance'
    derived=infer(public)
    assert sorted(map(canonical,derived))==sorted(map(canonical,package['truth'])), 'truth differs from independent reconciliation'
    # Replay generator causal edits without using truth to reconstruct the observed tables.
    replay=copy.deepcopy(history)
    def replace_or_append(table,row):
        rid=record_id(table,row)
        for i,old in enumerate(replay[table]):
            if record_id(table,old)==rid: replay[table][i]=copy.deepcopy(row); return
        replay[table].append(copy.deepcopy(row))
    for change in package['provenance']['changes']:
        after=change['after']
        if change['type']=='duplicate_invoice':
            replace_or_append('invoices',after['invoice'])
            for row in after['ledger']: replace_or_append('ledger',row)
        elif change['type']=='missing_or_partial_payment_allocation': replace_or_append('payments',after)
        elif change['type'].startswith('wrong_fx'):
            replace_or_append('payments',after['payment'])
            for row in after['ledger']: replace_or_append('ledger',row)
        else:
            for row in after: replace_or_append('ledger',row)
    for table in tables:
        key=lambda row:record_id(table,row)
        assert sorted(replay[table],key=key)==sorted(tables[table],key=key), 'causal replay mismatch'
    derived_by_key={canonical(f):f for f in derived}
    ids={record_id(t,r) for t,rows in tables.items() for r in rows}
    ids|={r['doc_id'] for t in ('invoices','payments') for r in tables[t]}; ids.add('policy-v2')
    for t in package['truth']:
        f=derived_by_key[canonical(t)]
        assert t['evidence_sets'] and all(set(s)<=ids for s in t['evidence_sets']), 'unavailable evidence'
        assert any(set(s)==set(f['evidence_ids']) for s in t['evidence_sets']), 'insufficient evidence set'
    return {'valid':True,'issues':len(derived),'records':sum(map(len,tables.values()))}
