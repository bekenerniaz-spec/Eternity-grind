"""Public-record reconciliation, independent from generator provenance/truth."""
from collections import defaultdict
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from schemas import finding

def infer(public):
    tables=public['tables']; policy=public['policy']; base=policy['base_currency']; evidence_policy=policy['policy_id']
    invoices=tables['invoices']; payments=tables['payments']; ledger=tables['ledger']; rates=tables['fx']
    out=[]; groups=defaultdict(list); by_id={i['invoice_id']:i for i in invoices}
    for inv in invoices: groups[(inv['entity_id'],inv['supplier_number'])].append(inv)
    for group in groups.values():
        if len(group)>1:
            out.append(finding('duplicate_invoice',[i['invoice_id'] for i in group],
                               sum(i['total_minor'] for i in group[1:]),group[0]['currency'],
                               [i['doc_id'] for i in group]+[evidence_policy]))
    fx={(r['date'],r['source_currency'],r['target_currency']):r for r in rates}
    for p in payments:
        references=p['invoice_refs'] or []
        allocated=sum(r['amount_minor'] for r in references)
        if allocated!=p['amount_minor']:
            targets=p['remittance_invoice_ids']
            out.append(finding('missing_or_partial_payment_allocation',[p['payment_id']]+targets,
                               abs(p['amount_minor']-allocated),p['currency'],
                               [p['doc_id']]+[by_id[x]['doc_id'] for x in targets]+[evidence_policy]))
        if p['currency']==base: continue
        date=datetime.fromisoformat(p['timestamp']).date().isoformat()
        correct=fx[(date,p['currency'],base)]
        kind='wrong_fx_date' if p['fx_date']!=date else 'wrong_fx_rate'
        if p['fx_date']!=date or Decimal(p['fx_rate'])!=Decimal(correct['rate']):
            expected=int((Decimal(p['amount_minor'])*Decimal(correct['rate'])).quantize(Decimal(1),rounding=ROUND_HALF_UP))
            out.append(finding(kind,[p['payment_id']],abs(p['base_amount_minor']-expected),base,
                               [p['doc_id'],correct['rate_id'],evidence_policy]))
    end=datetime.fromisoformat(policy['period_end']); start=datetime.fromisoformat(policy['period_start'])
    posting_groups=defaultdict(list)
    for row in ledger:
        if row['posting_kind']=='invoice': posting_groups[row['invoice_id']].append(row)
    for iid,rows in posting_groups.items():
        inv=by_id[iid]; issue=datetime.fromisoformat(inv['issued_at'])
        if any((start<=datetime.fromisoformat(row['timestamp'])<end)!=(start<=issue<end) for row in rows):
            out.append(finding('period_cutoff_error',[iid]+[r['row_id'] for r in rows],
                               sum(r['debit_minor'] for r in rows),base,
                               [inv['doc_id']]+[r['row_id'] for r in rows]+[evidence_policy]))
    return sorted(out,key=lambda f:(f['type'],f['affected_ids']))
