"""Untrusted policy executable. Only public protocol and pure reconciliation are imported."""
import argparse
import json
import random
import sys
from analysis import infer
from schemas import TABLES, TYPES, finding

class Finished(Exception): pass

class Client:
    def __init__(self): self.observation=json.loads(sys.stdin.readline())['observation']
    def call(self,tool,**args):
        print(json.dumps(dict(tool=tool,args=args)),flush=True)
        response=json.loads(sys.stdin.readline()); obs,reward,terminated,truncated,info=response['transition']
        if terminated or truncated: raise Finished()
        return obs
    def fetch(self,table):
        rows=[]; cursor=None
        while True:
            obs=self.call('list_records',table=table,cursor=cursor,limit=50)
            if not obs['ok']: return rows
            rows+=obs['result']['rows']; cursor=obs['result']['next_cursor']
            if cursor is None: return rows
    def submit(self,findings):
        return self.call('submit',findings=dict(episode_id=self.observation['episode_id'],findings=findings))

def run(name):
    client=Client(); rng=random.Random(1234)
    try:
        if name=='random':
            for _ in range(12): client.call('list_records',table=rng.choice(TABLES),limit=rng.randrange(1,51))
            client.submit([])
        public=dict(manifest=client.observation['manifest'],policy=client.observation['policy'],
                    tables={t:client.fetch(t) for t in TABLES})
        if name=='reconciliation': client.submit(infer(public))
        elif name=='flag_all':
            candidates=[]
            for inv in public['tables']['invoices']:
                for kind in TYPES:
                    candidates.append(finding(kind,[inv['invoice_id']],inv['total_minor'],inv['currency'],[inv['doc_id']]))
            client.submit(candidates[:30])
    except Finished: return

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--policy',choices=['random','reconciliation','flag_all'],default='reconciliation')
    run(parser.parse_args().policy)
