"""Strict primitive/reference validation without third-party dependencies."""
from datetime import datetime
from decimal import Decimal
from data import record_id

FIELDS={
 'ledger':{'row_id':'s','timestamp':'time','account':'s','debit_minor':'i','credit_minor':'i','currency':'s','entity_id':'s','invoice_id':'nullable','payment_id':'nullable','posting_kind':'s'},
 'invoices':{'doc_id':'s','invoice_id':'s','entity_id':'s','supplier_number':'s','issued_at':'time','due_at':'time','currency':'s','total_minor':'i','line_items':'list'},
 'payments':{'doc_id':'s','payment_id':'s','timestamp':'time','currency':'s','amount_minor':'i','invoice_refs':'nullable_list','remittance_invoice_ids':'list','fx_date':'s','fx_rate':'decimal','base_amount_minor':'i'},
 'fx':{'rate_id':'s','date':'s','source_currency':'s','target_currency':'s','rate':'decimal'}
}

def validate_public(public):
    if not __debug__: raise RuntimeError('validation requires Python without -O')
    manifest=public['manifest']; tables=public['tables']; policy=public['policy']
    for key in ('schema_version','episode_id','base_currency','period_start','period_end','timezone','currency_exponents','counts','rounding','record_count','document_count'):
        assert key in manifest,'missing manifest field'
    assert manifest['document_count']==len(tables['invoices'])+len(tables['payments'])
    assert manifest['record_count']==sum(len(r) for r in tables.values())
    all_ids=[]; docs=[]
    for table,rows in tables.items():
        for row in rows:
            for key,kind in FIELDS[table].items():
                assert key in row,'missing public field '+key
                value=row[key]
                if kind in ('s','time','decimal'): assert isinstance(value,str) and value,'invalid string'
                if kind=='i': assert type(value) is int,'invalid integer'
                if kind=='nullable': assert value is None or isinstance(value,str),'invalid nullable reference'
                if kind=='list': assert isinstance(value,list),'invalid list'
                if kind=='nullable_list': assert value is None or isinstance(value,list),'invalid refs'
                if kind=='time': assert datetime.fromisoformat(value).utcoffset() is not None,'missing offset'
                if kind=='decimal': assert Decimal(value).is_finite() and Decimal(value)>0,'invalid FX rate'
            all_ids.append(record_id(table,row))
            if 'doc_id' in row: docs.append(row['doc_id'])
    assert len(set(all_ids+docs))==len(all_ids+docs),'IDs must be globally unique'
    invoices={r['invoice_id'] for r in tables['invoices']}; payments={r['payment_id'] for r in tables['payments']}
    for row in tables['ledger']:
        assert row['invoice_id'] is None or row['invoice_id'] in invoices,'unknown invoice'
        assert row['payment_id'] is None or row['payment_id'] in payments,'unknown payment'
        assert row['currency'] in manifest['currency_exponents'],'unknown currency'
    for row in tables['payments']:
        for ref in row['invoice_refs'] or []:
            assert set(ref)=={'invoice_id','amount_minor'} and ref['invoice_id'] in invoices and type(ref['amount_minor']) is int,'invalid allocation'
        assert all(i in invoices for i in row['remittance_invoice_ids']),'unknown remittance invoice'
    return True
