"""Trusted orchestrator. --backend docker isolates the agent; process is smoke-test only."""
import argparse
import copy
import json
import os
from pathlib import Path
import queue
import secrets
import subprocess
import sys
import threading
import time
import uuid
from env import FinanceAuditEnv
from schemas import finding
from private_config import load_key

ROOT=Path(__file__).resolve().parent

def oracle(env):
    # Evaluator-only. Not shipped in the agent image.
    return dict(episode_id=env.public['manifest']['episode_id'],findings=[
        finding(t['type'],t['affected_ids'],t['expected_amount_minor'],t['currency'],t['evidence_sets'][0]) for t in env.package['truth']])

def run_episode(policy,seed,config=None,backend='docker',secret=None,mode='eval'):
    if backend not in ('docker','process'): raise ValueError('invalid backend')
    env=FinanceAuditEnv(mode,secret=secret or load_key()); obs,_=env.reset(seed,config)
    started=time.monotonic()
    if policy=='oracle':
        env.step(dict(tool='submit',args=dict(findings=oracle(env))))
        return env,time.monotonic()-started
    if backend=='docker':
        name='fin-audit-'+uuid.uuid4().hex
        command=['docker','run','--rm','-i','--name',name,'--network=none','--read-only',
                 '--user','65532:65532','--cap-drop=ALL','--security-opt=no-new-privileges',
                 '--pids-limit=32','--cpus=2','--memory=512m','--memory-swap=512m',
                 '--tmpfs','/tmp:rw,noexec,nosuid,size=4m','fin-audit-agent:2', '--policy',policy]
    else:
        name=None
        command=[sys.executable,'-I','-B',str(ROOT/'agent.py'),'--policy',policy]
        # -I removes script path: a tiny isolated launcher adds only this project path.
        command=[sys.executable,'-I','-B','-c',
                 'import runpy,sys;sys.path.insert(0,sys.argv[1]);sys.argv=["agent.py"]+sys.argv[2:];runpy.run_path(sys.path[0]+"/agent.py",run_name="__main__")',
                 str(ROOT),'--policy',policy]
    safe_env={k:v for k,v in os.environ.items() if k.upper() in ('PATH','SYSTEMROOT','WINDIR','TEMP','TMP','DOCKER_HOST','DOCKER_CONTEXT','USERPROFILE','HOME','APPDATA','LOCALAPPDATA')}
    # process backend has filesystem access and is explicitly not a security boundary.
    process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                             cwd=ROOT,env=safe_env,text=True,encoding='utf-8',bufsize=1)
    messages=queue.Queue(maxsize=2); stop=threading.Event()
    def reader():
        try:
            while not stop.is_set():
                line=process.stdout.readline(65537)
                if not line: break
                while not stop.is_set():
                    try: messages.put(line,timeout=.1); break
                    except queue.Full: pass
        finally:
            try: messages.put_nowait(None)
            except queue.Full: pass
    thread=threading.Thread(target=reader,daemon=True); thread.start()
    def send(obj):
        # A malicious child may stop reading. Bound writes as well as reads.
        completed=queue.Queue(maxsize=1)
        def write():
            try:
                process.stdin.write(json.dumps(obj,allow_nan=False)+'\n'); process.stdin.flush()
                completed.put(None)
            except (BrokenPipeError,OSError,ValueError) as error: completed.put(error)
        writer=threading.Thread(target=write,daemon=True); writer.start()
        remaining=max(.001,60-(time.monotonic()-started))
        try: error=completed.get(timeout=remaining)
        except queue.Empty: raise TimeoutError('agent stopped reading')
        if error: raise error
    try:
        send({'observation':obs})
        while not env.done:
            remaining=60-(time.monotonic()-started)
            if remaining<=0: env.truncate('timeout'); break
            try: line=messages.get(timeout=remaining)
            except queue.Empty: env.truncate('timeout'); break
            if line is None: env.truncate('agent exited'); break
            if len(line)>65536 or not line.endswith('\n'):
                env.truncate('oversized protocol message'); break
            try: action=json.loads(line,parse_constant=lambda _:None)
            except (ValueError,RecursionError): action=None
            transition=env.step(action)
            send({'transition':transition})
    except (BrokenPipeError,OSError,ValueError):
        if not env.done: env.truncate('transport failure')
    finally:
        stop.set()
        if process.poll() is None:
            try: process.wait(timeout=.2)
            except subprocess.TimeoutExpired: process.kill()
        process.wait(timeout=5)
        if name:
            subprocess.run(['docker','rm','-f',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
        process.stdin.close(); process.stdout.close(); thread.join(timeout=1)
    return env,time.monotonic()-started

def main():
    p=argparse.ArgumentParser(); p.add_argument('--backend',choices=['docker','process'],default='docker')
    p.add_argument('--policy',choices=['reconciliation','random','flag_all','oracle'],default='reconciliation')
    p.add_argument('--seed',type=int,default=2000); p.add_argument('--clean',action='store_true'); p.add_argument('--output',type=Path,default=Path('run-output'))
    args=p.parse_args(); env,elapsed=run_episode(args.policy,args.seed,{'clean':args.clean},args.backend)
    args.output.mkdir(parents=True,exist_ok=True)
    # This is evaluator output, NOT a policy response. Write only after the run.
    report=dict(backend=args.backend,security='container-isolation' if args.backend=='docker' else 'NOT_ISOLATED_SMOKE_ONLY',
                policy=args.policy,steps=env.steps,seconds=elapsed,result=env.result)
    (args.output/'evaluator-report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (args.output/'trajectories.jsonl').write_text(''.join(json.dumps(t)+'\n' for t in env.trajectory),encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
